
const Circle = require('./circle');

const c = new Circle(10);
c.draw();