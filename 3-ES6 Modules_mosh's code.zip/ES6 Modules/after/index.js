
import {Circle} from './circle.js';

const c = new Circle(10);
c.draw();